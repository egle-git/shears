from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'ZJetsAnaDY'
config.section_('JobType')
config.JobType.outputFiles = ['HistoFiles.tgz']
config.JobType.scriptArgs = ['cfg=vjets.cfg']
config.JobType.pluginName = 'PrivateMC'
config.JobType.scriptExe = 'job_crabDY.sh'
config.JobType.psetName = 'donothing_cfg.py'
config.JobType.inputFiles = ['../runZJets_newformat', '../RooUnfold/libRooUnfold.so', '../RooUnfold/RooUnfoldDict_rdict.pcm', '../EfficiencyTables.tgz', '../rcdata.2016.v3.tgz', '../histList.txt', 'vjets.cfg', '../unfolding.cfg']
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.outLFNDirBase = '/store/group/phys_muon/agrebeny/HistoFiles2016'
config.Data.splitting = 'EventBased'
config.Data.totalUnits = 17
config.Data.publication = False
config.section_('User')
config.section_('Site')
config.Site.whitelist = ['T2_CH_CERN']
config.Site.storageSite = 'T2_CH_CERN'
